Authors
=======

* Marc Schlaich - http://www.schlamar.org
* Rick van Hattem - http://wol.ph
* Buck Evan - https://github.com/bukzor
* Eric Larson - http://larsoner.com
* Marc Abramowitz - http://marc-abramowitz.com
* Thomas Kluyver - https://github.com/takluyver
* Guillaume Ayoub - http://www.yabz.fr
* Federico Ceratto - http://firelet.net
* Josh Kalderimis - http://blog.cookiestack.com
* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Christian Ledermann - https://github.com/cleder
* Alec Nikolas Reiter - https://github.com/justanr
* Patrick Lannigan - https://github.com/plannigan
* David Szotten - https://github.com/davidszotten
* Michael Elovskikh - https://github.com/wronglink
* Saurabh Kumar - https://github.com/theskumar
* Michael Elovskikh - https://github.com/wronglink
* Daniel Hahler - https://daniel.hahler.de
* Florian Bruhin - http://www.the-compiler.org
* Zoltan Kozma - https://github.com/kozmaz87
* Francis Niu - https://flniu.github.io
* Jannis Leidel - https://github.com/jezdez
* Ryan Hiebert - http://ryanhiebert.com/
* Terence Honles - https://github.com/terencehonles
* Jeremy Bowman - https://github.com/jmbowman
* Samuel Giffard - https://github.com/Mulugruntz
* Семён Марьясин - https://github.com/MarSoft
* Alexander Shadchin - https://github.com/shadchin
* Thomas Grainger - https://graingert.co.uk
* Juanjo Bazán - https://github.com/xuanxu
* Andrew Murray - https://github.com/radarhere
* Ned Batchelder - https://nedbatchelder.com/
* Albert Tugushev - https://github.com/atugushev
* Martín Gaitán - https://github.com/mgaitan
* Hugo van Kemenade - https://github.com/hugovk
* Michael Manganiello - https://github.com/adamantike
* Anders Hovmöller - https://github.com/boxed
* Zac Hatfield-Dodds - https://zhd.dev
* Mateus Berardo de Souza Terra - https://github.com/MatTerra
* Ganden Schaffner - https://github.com/gschaffner
* Michał Górny - https://github.com/mgorny
* Bernát Gábor - https://github.com/gaborbernat
* Pamela McA'Nulty - https://github.com/PamelaM
* Christian Riedel - https://github.com/Cielquan
* Chris Sreesangkom - https://github.com/csreesan
* Sorin Sbarnea - https://github.com/ssbarnea
* Brian Rutledge - https://github.com/bhrutledge
* Danilo Šegan - https://github.com/dsegan
* Michał Bielawski - https://github.com/D3X
